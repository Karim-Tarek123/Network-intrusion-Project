import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import warnings
import scipy.stats as st
from sklearn.metrics import mean_squared_error
from scipy.stats._continuous_distns import _distn_names

from sklearn.preprocessing import OneHotEncoder
from sklearn.model_selection import train_test_split

# Suppress warnings for cleaner output
warnings.filterwarnings('ignore')

# ============================================================
# =====================  MILESTONE 1  =========================
# ============================================================

# 1a. Load the dataset
df = pd.read_csv('Train_data_updated.csv')
fields = df.columns.to_list()

# 1b. List the data fields
print("1b. Data fields:", df.columns.tolist())
print("\n1b. Columns : " , df.dtypes)

# ============================================================
# 1c. Missing data and inf check
# ============================================================

print("\n1c. Missing data check:", df.isnull().sum())
print("Inf data check:", np.isinf(df.select_dtypes(include=['int64', 'float64'])).sum().sum())

# ============================================================
# 1d. Correct data types for numeric/string columns
# ============================================================

categorical_cols = ['Switch ID', 'Port Number', 'Label', 'Binary Label']
numeric_cols = [col for col in df.columns if col not in categorical_cols and df[col].dtype == 'object']

changes_made = False

for column in numeric_cols:
    original_dtype = df[column].dtype
    df[column] = pd.to_numeric(df[column], errors='coerce')
    if df[column].dtype in ['int64', 'float64'] and original_dtype != df[column].dtype:
        print(f"Converted {column} to numeric type: {df[column].dtype}")
        changes_made = True

if not changes_made:
    print("No data type conversions were needed. All data types are correct and unchanged.")

print("\nUpdated data types:\n", df.dtypes)

# ============================================================
# 1e. Standardization of Label + Binary Label
# ============================================================

letter_mappings = {
    frozenset(['t','c','p','s','y','n']): 'TCP-SYN',
    frozenset(['d','i','v','e','r','s','i','o','n']): 'DIVERSION',
    frozenset(['p','o','r','t','s','c','a','n']): 'PORTSCAN',
    frozenset(['a','t','t','a','c','k']): 'ATTACK',
    frozenset(['b','l','a','c','k','h','o','l','e']): 'BLACKHOLE',
    frozenset(['o','v','e','r','f','l','o','w']): 'OVERFLOW',
    frozenset(['n','o','r','m','a','l']): 'NORMAL'
}

def standardize_text(text):
    if pd.isna(text) or not isinstance(text, str):
        return text
    text = text.lower().strip()
    parts = text.split('-')
    all_letters = frozenset(c for part in parts for c in part if c.isalpha())
    for required_letters, standard_value in letter_mappings.items():
        if all_letters.issubset(required_letters):
            if standard_value == 'TCP-SYN' and any('tcp' in p or 'syn' in p for p in parts):
                return standard_value
            return standard_value
    return text

for col in ['Label', 'Binary Label']:
    df[col] = df[col].apply(standardize_text)

print("\nUpdated sample of categorical columns:")
print(df[['Label', 'Binary Label']].head())

# ============================================================
# 1f. Universal inconsistency correction
# ============================================================

print("\n" + "="*50)
print("1f. UNIVERSAL NEGATIVE VALUE CORRECTION")
print("="*50)

dup = df.duplicated().sum()
print(f"Duplicate rows: {dup}")
if dup:
    df = df.drop_duplicates().reset_index(drop=True)
    print(f"Removed {dup} duplicates (keeping first). New shape: {df.shape}")
else:
    print("No duplicates found.")

numeric_cols = df.select_dtypes(include=[np.number]).columns
true_neg_total = 0
sentinel_total = 0

for col in numeric_cols:
    true_neg = ((df[col] < 0) & (df[col] != -1)).sum()
    sentinel = (df[col] == -1).sum()
    if true_neg or sentinel:
        print(f"\nColumn: {col}")
        if true_neg:
            print(f"  {true_neg} true negatives (<0, != -1) -> replaced with 0")
            true_neg_total += true_neg
        if sentinel:
            print(f"  {sentinel} sentinel values (-1) -> replaced with NaN")
            sentinel_total += sentinel
    df[col] = df[col].apply(lambda x: 0 if (x < 0 and x != -1) else (np.nan if x == -1 else x))

print("\nSummary:")
print(f"  Total true negatives fixed: {true_neg_total}")
print(f"  Total -1 sentinels converted to NaN: {sentinel_total}")
print("="*50)

df_copy = df.copy()

# ============================================================
# 1g. Unique Categories
# ============================================================

categorical_cols = df.select_dtypes(include=['object', 'bool']).columns

print("\n=== Task 1g: Unique Category Counts ===")
for col in categorical_cols:
    print(f"- {col}: {df[col].nunique()} unique values")
print("=== End of Task 1g ===")

# ============================================================
# One-Hot Encoding of Attack Types
# ============================================================

def adding_Attack_Types(df):
    attack_types = df['Label'].unique()
    for attack in attack_types:
        col_name = f"Attack_{attack.replace(' ', '_')}"
        df[col_name] = (df['Label'] == attack).astype(int)
    return df

# ============================================================
# TASK 1: Z-SCORE WITH PLOTS
# ============================================================

def task1_zscore_anomaly_with_plot(df_input):
    """
    Task 1: Z-Score Anomaly Detection with Performance Plot
    """
    # Data preparation
    df_work = df_input.copy()
    y = (df_work['Binary Label'] == 'ATTACK').astype(int)
    X = df_work.drop(columns=['Label', 'Binary Label'], errors='ignore')

    numeric_cols = X.select_dtypes(include=[np.number]).columns
    X_numeric = X[numeric_cols]

    # Remove constant fields
    constant_fields = [c for c in X_numeric.columns if X_numeric[c].std() == 0]
    X_numeric = X_numeric.drop(columns=constant_fields)

    # Train/Test split
    np.random.seed(42)
    idx = np.random.permutation(len(X_numeric))
    n_train = int(0.7 * len(idx))

    train_idx = idx[:n_train]
    test_idx = idx[n_train:]

    X_train = X_numeric.iloc[train_idx].reset_index(drop=True)
    X_test = X_numeric.iloc[test_idx].reset_index(drop=True)
    y_train = y.iloc[train_idx].reset_index(drop=True)
    y_test = y.iloc[test_idx].reset_index(drop=True)

    # Calculate Z-scores
    mu = X_train.mean()
    sigma = X_train.std().replace(0, 1)
    X_test_z = (X_test - mu) / sigma
    X_test_z = X_test_z.fillna(0)
    scores = X_test_z.abs().max(axis=1)

    # Thresholds
    thresholds = [0.5, 0.75, 1.0, 1.25, 1.5, 1.75, 2.0, 2.25, 2.5, 2.75, 3.0, 3.5, 4.0]
    results = []

    def metrics(y_true, y_pred):
        tp = ((y_pred == 1) & (y_true == 1)).sum()
        fp = ((y_pred == 1) & (y_true == 0)).sum()
        tn = ((y_pred == 0) & (y_true == 0)).sum()
        fn = ((y_pred == 0) & (y_true == 1)).sum()
        acc = (tp + tn) / len(y_true)
        prec = tp / (tp + fp) if (tp + fp) > 0 else 0
        rec = tp / (tp + fn) if (tp + fn) > 0 else 0
        
        return acc, prec, rec, tp, fp, tn, fn

    for th in thresholds:
        y_pred = (scores > th).astype(int)
        acc, prec, rec, tp, fp, tn, fn = metrics(y_test, y_pred)
        results.append({
            "Threshold": th,
            "Accuracy": acc,
            "Precision": prec,
            "Recall": rec,
            
            "TP": tp, "FP": fp, "TN": tn, "FN": fn
        })

    results_df = pd.DataFrame(results)
    
    # === CREATE PLOT ===
    plt.figure(figsize=(12, 7))
    
    plt.plot(results_df['Threshold'], results_df['Accuracy'], 
             'o-', label='Accuracy', linewidth=2.5, markersize=8, color='blue')
    plt.plot(results_df['Threshold'], results_df['Precision'], 
             's-', label='Precision', linewidth=2.5, markersize=8, color='orange')
    plt.plot(results_df['Threshold'], results_df['Recall'], 
             '^-', label='Recall', linewidth=3, markersize=10, color='green')
    
    
    # Mark best threshold (highest Recall)
    best_idx = results_df['Recall'].idxmax()
    best_th = results_df.loc[best_idx, 'Threshold']
    best_f1 = results_df.loc[best_idx, 'Recall']
    
    plt.axvline(best_th, color='red', linestyle='--', linewidth=2, alpha=0.5)
    plt.text(best_th + 0.1, 0.9, 
             f'Best Threshold: {best_th}\nRecall-Score: {best_f1:.4f}',
             bbox=dict(boxstyle='round', facecolor='yellow', alpha=0.7),
             fontsize=10, fontweight='bold')
    
    plt.xlabel('Z-Score Threshold', fontsize=13, fontweight='bold')
    plt.ylabel('Metric Value', fontsize=13, fontweight='bold')
    plt.title('Z-Score Anomaly Detection Performance\n(Milestone 2 - Task 1)', 
              fontsize=15, fontweight='bold')
    plt.legend(fontsize=11, loc='best')
    plt.grid(True, alpha=0.3, linestyle='--')
    plt.ylim(0, 1.05)
    plt.tight_layout()
    
    # Save plot
    plt.savefig('task1_zscore_performance.png', dpi=300, bbox_inches='tight')
    plt.close()
    
    print("\n Plot saved: task1_zscore_performance.png")
    
    return results_df


# ============================================================
# TASK 2: PDF FITTING WITH RAINBOW SPAGHETTI PLOTS
# ============================================================

def generate_pdf_plots():
    """
    Improved PDF fitting with rainbow spaghetti plots showing all distributions
    """
    print("\n" + "="*80)
    print("STARTING PDF FITTING FOR CONTINUOUS FEATURES (MILESTONE 2 & 3 TASK 2)")
    print("="*80)
    
    global DISTRIBUTIONS
    DISTRIBUTIONS = [getattr(st, d) for d in _distn_names 
                     if d not in ['levy_stable', 'studentized_range']]
    print(f"Trying {len(DISTRIBUTIONS)} official SciPy continuous distributions")
    
    def safe_filename(name):
        return name.replace('/', 'per').replace(' ', '').replace('\\', '').replace(':', '')
    
    def best_fit_distribution(data, bins=80, ax=None):
        y, x = np.histogram(data, bins=bins, density=True)
        x = (x[:-1] + x[1:]) / 2.0
        fits = []
        n_bins = len(y)
        for dist in DISTRIBUTIONS:
            try:
                params = dist.fit(data)
                pdf = dist.pdf(x, *params[:-2], loc=params[-2], scale=params[-1])
                sse = np.sum((y - pdf)**2)
                mse = sse / n_bins if n_bins > 0 else sse  # Calculate MSE
                if ax is not None:
                    ax.plot(x, pdf, alpha=0.5, lw=0.8)  # Rainbow spaghetti
                fits.append((dist, params, mse))
            except:
                pass
        return sorted(fits, key=lambda x: x[2])
    
    def plot_column(series, col_name, suffix="", condition_name=""):
        data = series.dropna()
        if len(data) < 50:
            print(f"   SKIPPED: {col_name}{suffix} (only {len(data)} points)")
            return None
        
        name = safe_filename(col_name + suffix)
        print(f"   -> {col_name}{suffix} ({len(data)} points)")
        
        # RAINBOW SPAGHETTI PLOT
        plt.figure(figsize=(16, 10))
        ax = plt.gca()
        ax.hist(data, bins=80, density=True, alpha=0.6, color='lightblue', 
                edgecolor='white', label='Data', zorder=5)
        ylim = ax.get_ylim()
        
        # Fit all distributions and plot them (rainbow spaghetti)
        fits = best_fit_distribution(data, bins=80, ax=ax)
        ax.set_ylim(ylim)
        
        if not fits:
            print(f"   NO FITS FOUND for {col_name}{suffix}")
            plt.close()
            return None
        
        # Get best fit
        best_dist, best_params, best_mse = fits[0]
        
        # Plot BEST FIT on top in RED
        y_h, edges = np.histogram(data, bins=80, density=True)
        x_mid = (edges[:-1] + edges[1:]) / 2
        pdf_best = best_dist.pdf(x_mid, *best_params[:-2], loc=best_params[-2], scale=best_params[-1])
        ax.plot(x_mid, pdf_best, color='red', lw=4, label=f'BEST: {best_dist.name.upper()}', zorder=10)
        
        # Format title with parameters
        shapes = best_dist.shapes.split(', ') if best_dist.shapes else []
        names = shapes + ['loc', 'scale']
        param_str = ', '.join([f'{n}={v:.4g}' for n, v in zip(names, best_params)])
        
        ax.set_title(f'{col_name} - {condition_name}\n'
                    f'All Distributions (Rainbow) + Best Fit (Red)\n'
                    f'Best: {best_dist.name.upper()}({param_str}) | MSE={best_mse:.2e}',
                    fontsize=14, fontweight='bold', pad=20)
        ax.set_xlabel(col_name, fontsize=12)
        ax.set_ylabel('Density', fontsize=12)
        ax.legend(fontsize=11)
        ax.grid(True, alpha=0.3)
        plt.tight_layout()
        plt.savefig(f"{name}_rainbow_spaghetti.png", dpi=300, bbox_inches='tight')
        plt.close()
        
        print(f"      BEST: {best_dist.name.upper()} | MSE={best_mse:.2e}")
        print(f"      Saved: {name}_rainbow_spaghetti.png")
        
        return {'dist': best_dist.name, 'params': best_params, 'mse': best_mse}
    
    # Ensure Binary Label is numeric (0/1) for consistency
    df_work = df_copy.copy()
    if df_work['Binary Label'].dtype == 'object':
        df_work['Binary Label'] = (df_work['Binary Label'] == 'ATTACK').astype(int)
    
    # Main execution - Continuous columns
    cols = [c for c in df_work.select_dtypes(include=np.number).columns 
            if df_work[c].nunique() > 50 and c not in ['Binary Label']]
    
    print(f"\nFound {len(cols)} continuous columns to analyze\n")
    
    pdf_summary = []
    
    for idx, col in enumerate(cols, 1):
        print(f"\n[{idx}/{len(cols)}] Processing: {col}")
        print("-" * 80)
        
        col_results = {'Column': col}
        
        # OVERALL
        result = plot_column(df_work[col], col, "_OVERALL", "Overall Data")
        if result:
            col_results['Best_Overall'] = result['dist']
            col_results['MSE_Overall'] = f"{result['mse']:.6e}"
        
        # NORMAL
        normal_data = df_work[df_work['Binary Label'] == 0]
        if len(normal_data) > 100:
            result = plot_column(normal_data[col], col, "_NORMAL", "Normal Traffic (No Anomaly)")
            if result:
                col_results['Best_Normal'] = result['dist']
                col_results['MSE_Normal'] = f"{result['mse']:.6e}"
        
        # ATTACK
        attack_data = df_work[df_work['Binary Label'] == 1]
        if len(attack_data) > 100:
            result = plot_column(attack_data[col], col, "_ATTACK", "Attack Traffic (Anomaly)")
            if result:
                col_results['Best_Attack'] = result['dist']
                col_results['MSE_Attack'] = f"{result['mse']:.6e}"
        
        pdf_summary.append(col_results)
    
    # BONUS: PER ATTACK TYPE
    print("\n" + "="*80)
    print("BONUS: PDF ANALYSIS PER ATTACK TYPE")
    print("="*80)
    
    if 'Label' in df_copy.columns:
        for attack in df_copy['Label'].dropna().unique():
            attack_subset = df_copy[df_copy['Label'] == attack]
            if len(attack_subset) < 100:
                print(f"\nSKIPPED: {attack} (only {len(attack_subset)} samples)")
                continue
            
            print(f"\n{'='*60}")
            print(f"Attack Type: {attack.upper()} ({len(attack_subset)} samples)")
            print(f"{'='*60}")
            
            # Analyze top 5 most varying columns for this attack type
            for col in cols[:5]:  # Top 5 columns
                attack_name_safe = attack.upper().replace(' ', '_')
                result = plot_column(attack_subset[col], col, 
                                   f"_{attack_name_safe}", 
                                   f"{attack.upper()} Attack")
    
    # Print summary table
    print("\n" + "="*80)
    print("PDF SUMMARY TABLE")
    print("="*80)
    summary_df = pd.DataFrame(pdf_summary)
    print(summary_df.to_string(index=False))
    
    print("\n" + "="*80)
    print("ALL PDF PLOTS COMPLETED!")
    print("  - Rainbow spaghetti: All distributions in faded colors")
    print("  - Best fit: Highlighted in RED on top")
    print("  - Saved for: Overall, Normal, Attack, and Bonus per-attack-type")
    print("="*80)
    
    return summary_df


# ============================================================
# PMF PLOTS FOR CATEGORICAL COLUMNS
# ============================================================

def generate_pmf_plots():
    print("\n" + "="*80)
    print("TASK 2: PMF ANALYSIS")
    print("="*80)
    
    df_work = df_copy.copy()
    
    # Convert Binary Label if needed
    if df_work['Binary Label'].dtype == 'object':
        df_work['Binary Label'] = (df_work['Binary Label'] == 'ATTACK').astype(int)
    
    # Discrete detection
    discrete_cols = [
        c for c in df_work.columns
        if df_work[c].nunique() <= 20
        and c not in ['Binary Label', 'Label']
        and not c.startswith('Attack_')
        and not df_work[c].isna().all()
    ]
    print(f"Found {len(discrete_cols)} discrete columns: {discrete_cols}\n")
    
    def safe_filename(name):
        return "".join(c if c.isalnum() or c == "_" else "_" for c in str(name))
    
    # ======================================================================
    # PMF STORAGE
    # ======================================================================
    PMF_STORAGE = {}
    for col in discrete_cols:
        all_values = sorted(df_work[col].dropna().unique())
        pmf_all = df_work[col].value_counts(normalize=True).reindex(all_values, fill_value=0)
        pmf_normal = df_work[df_work['Binary Label'] == 0][col].value_counts(normalize=True).reindex(all_values, fill_value=0)
        pmf_attack = df_work[df_work['Binary Label'] == 1][col].value_counts(normalize=True).reindex(all_values, fill_value=0)
        PMF_STORAGE[col] = {
            'categories': all_values,
            'PMF_Overall': pmf_all.to_dict(),
            'PMF_Normal': pmf_normal.to_dict(),
            'PMF_Attack': pmf_attack.to_dict()
        }
    
    # ======================================================================
    # 1. MAIN COMPARISON — Overall / Normal / All Attacks
    # ======================================================================
    print("\nGenerating main comparison figures (Overall / Normal / All Attacks)...")
    for col in discrete_cols:
        all_values = sorted(df_work[col].dropna().unique())
        pmf_all = df_work[col].value_counts(normalize=True).reindex(all_values, fill_value=0)
        pmf_normal = df_work[df_work['Binary Label'] == 0][col].value_counts(normalize=True).reindex(all_values, fill_value=0)
        pmf_attack = df_work[df_work['Binary Label'] == 1][col].value_counts(normalize=True).reindex(all_values, fill_value=0)
        
        fig, axes = plt.subplots(1, 3, figsize=(28, 7), sharey=True)
        fig.suptitle(f"PMF Comparison for {col}", fontsize=20, fontweight='bold')
        
        # Overall
        axes[0].bar(all_values, pmf_all, color='#1f77b4', edgecolor='black')
        axes[0].set_title("Overall PMF")
        axes[0].set_ylabel("Probability")
        axes[0].grid(axis='y', alpha=0.3)
        
        # Normal
        axes[1].bar(all_values, pmf_normal, color='#2ca02c', edgecolor='black')
        axes[1].set_title("Normal PMF")
        axes[1].grid(axis='y', alpha=0.3)
        
        # All Attacks
        axes[2].bar(all_values, pmf_attack, color='#d62728', edgecolor='black')
        axes[2].set_title("All Attacks PMF")
        axes[2].grid(axis='y', alpha=0.3)
        
        for ax in axes:
            ax.set_xticks(all_values)
            ax.set_xticklabels(all_values, rotation=60, ha='right')
        
        plt.tight_layout(rect=[0, 0, 1, 0.93])
        filename = f"PMF_COMPARISON_{safe_filename(col)}.png"
        plt.savefig(filename, dpi=300, bbox_inches='tight')
        plt.close()
        print(f" Saved: {filename}")
    
    # ======================================================================
    # 2. PER ATTACK TYPE — Overall / Normal / Specific Attack (NO DUPLICATE NORMAL!)
    # ======================================================================
    print("\n" + " BONUS: PMF PER ATTACK TYPE ".center(80, "="))
    
    if "Label" in df_copy.columns:
        # Define your exact attack types
        desired_attacks = ['OVERFLOW', 'DIVERSION', 'TCP-SYN', 'BLACKHOLE', 'PORTSCAN']
        
        for attack in desired_attacks:
            # Case-insensitive match
            sub = df_work[df_work['Label'].astype(str).str.upper() == attack]
            if len(sub) < 50:
                print(f"Skipping {attack} — only {len(sub)} samples")
                continue
                
            print(f"\n-> {attack} ({len(sub)} samples)")
            
            for col in discrete_cols:
                all_values = sorted(df_work[col].dropna().unique())
                pmf_all = df_work[col].value_counts(normalize=True).reindex(all_values, fill_value=0)
                pmf_normal = df_work[df_work['Binary Label'] == 0][col].value_counts(normalize=True).reindex(all_values, fill_value=0)
                pmf_specific = sub[col].value_counts(normalize=True).reindex(all_values, fill_value=0)
                
                fig, axes = plt.subplots(1, 3, figsize=(28, 7), sharey=True)
                fig.suptitle(f"PMF Comparison for {col} – Attack Type: {attack}", 
                             fontsize=20, fontweight='bold')
                
                # 1. Overall
                axes[0].bar(all_values, pmf_all, color='#1f77b4', edgecolor='black')
                axes[0].set_title("Overall PMF")
                axes[0].set_ylabel("Probability")
                axes[0].grid(axis='y', alpha=0.3)
                
                # 2. Normal (only once!)
                axes[1].bar(all_values, pmf_normal, color='#2ca02c', edgecolor='black')
                axes[1].set_title("Normal PMF")
                axes[1].grid(axis='y', alpha=0.3)
                
                # 3. Specific Attack Only (NO NORMAL HERE!)
                axes[2].bar(all_values, pmf_specific, color='#d62728', edgecolor='black')
                axes[2].set_title(f"{attack} PMF")
                axes[2].grid(axis='y', alpha=0.3)
                
                for ax in axes:
                    ax.set_xticks(all_values)
                    ax.set_xticklabels(all_values, rotation=60, ha='right')
                
                plt.tight_layout(rect=[0, 0, 1, 0.93])
                filename = f"PMF_COMPARISON_{safe_filename(col)}_{attack}.png"
                plt.savefig(filename, dpi=300, bbox_inches='tight')
                plt.close()
                print(f"   Saved: {filename}")
    
    print("\n" + "="*80)
    print("PMF STORAGE SUMMARY")
    print("="*80)
    print(f"Stored PMFs for {len(discrete_cols)} discrete columns")
    print(f"Access example: PMF_STORAGE['column_name']['PMF_Normal'][value]")
    print("="*80)
    
    return PMF_STORAGE










# ============================================================
# EXAMPLE USAGE
# ============================================================

# After loading and cleaning your data with all Milestone 1 steps, run:

print("\n" + "="*80)
print("MILESTONE 2 - COMPLETE EXECUTION WITH ALL PLOTS")
print("="*80)

# Task 1
print("\n>>> TASK 1: Z-Score Anomaly Detection")
task1_results = task1_zscore_anomaly_with_plot(df_copy)  
print(task1_results)




# Task 2 - PMF (Improved)
print("\n>>> TASK 2b: PMF Fitting for Categorical Columns")
generate_pmf_plots()


PMF_STORAGE = generate_pmf_plots()   # ← your function call

def display_pmf_storage_full(PMF_STORAGE):
    print("\n" + "="*90)
    print("FULL PMF_STORAGE CONTENTS + TOP ATTACK INDICATORS")
    print("="*90)
    
    for col, data in PMF_STORAGE.items():
        values = data['categories']
        print(f"\nColumn: {col}  ({len(values)} unique values)")
        print("-" * 80)
        
        # FULL TABLE – Safe ASCII only
        print(f"{'Value':<12} {'Overall':<12} {'Normal':<12} {'Attack':<12} {'Delta (A-N)'}")
        print("-" * 80)
        
        diffs = []
        for val in values:
            p_all  = data['PMF_Overall'].get(val, 0)
            p_norm = data['PMF_Normal'].get(val, 0)
            p_att  = data['PMF_Attack'].get(val, 0)
            delta  = p_att - p_norm
            diffs.append((val, delta))
            
            direction = "Increase" if delta > 0 else ("Decrease" if delta < 0 else "No Change")
            print(f"{val:<12} {p_all:<12.6f} {p_norm:<12.6f} {p_att:<12.6f} {delta:+.6f}  [{direction}]")
        
        # TOP 5 ATTACK INDICATORS
        print(f"\nTop 5 Strongest Attack Indicators for '{col}':")
        top5 = sorted(diffs, key=lambda x: abs(x[1]), reverse=True)[:5]
        for val, delta in top5:
            direction = "Increase" if delta > 0 else ("Decrease" if delta < 0 else "No Change")
            strength = "EXTREME" if abs(delta) > 0.5 else "Very Strong" if abs(delta) > 0.2 else "Strong"
            print(f"   -> Value {val}: {strength} {direction} | Delta = {delta:+.6f}")
    
    print("\n" + "="*90)
    print("ANALYSIS COMPLETE – Ready for your report!")
    print("="*90)

# Run it safely
display_pmf_storage_full(PMF_STORAGE)




print("\n" + "="*80)
print("FULL CONTENTS OF PMF_STORAGE")
print("="*80)




#  # Task 2 - PDF (Improved with Rainbow Spaghetti)
print("\n>>> TASK 2a: PDF Fitting for Continuous Columns (Rainbow Spaghetti)")
pdf_results = generate_pdf_plots()
pdf_results.to_csv("task2_pdf_results.csv", index=False)
print("\n Task 2a complete: Results saved to task2_pdf_results.csv")
print("\n" + "="*80)

print("="*80)


print("="*80)