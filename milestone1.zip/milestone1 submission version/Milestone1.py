
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt


# 1a. Load the dataset
df = pd.read_csv('Train_data_updated.csv')
fields = df.columns.to_list()

# 1b. List the data fields
print("1b. Data fields:", df.columns.tolist())
print("\n1b. Columns : " , df.dtypes)

# Requirement 1c: Check if there is any missing data or inf data
print("\n1c. Missing data check:", df.isnull().sum())
print("Inf data check:", np.isinf(df.select_dtypes(include=['int64', 'float64'])).sum().sum())

# 1d. Correct data types (e.g., numeric values stored as strings)

# Define columns that should remain categorical/identifier (exclude from numeric conversion)
categorical_cols = ['Switch ID', 'Port Number', 'Label', 'Binary Label']

# Identify numeric columns (excluding categorical ones) that might be stored as strings
numeric_cols = [col for col in df.columns if col not in categorical_cols and df[col].dtype == 'object']

# Flag to track if any conversions occurred
changes_made = False

# Convert only potential numeric columns stored as strings to numeric type
for column in numeric_cols:
    original_dtype = df[column].dtype
    df[column] = pd.to_numeric(df[column], errors='coerce')
    if df[column].dtype in ['int64', 'float64'] and original_dtype != df[column].dtype:
        print(f"Converted {column} to numeric type: {df[column].dtype}")
        changes_made = True

# Check and display the result
if not changes_made:
    print("No data type conversions were needed. All data types are correct and unchanged.")

# Verify all columns' data types after correction
print("\nUpdated data types:\n", df.dtypes)

#Requirement 1e standardization
# Define mapping of letter sets to standardized values, including hyphen variations
letter_mappings = {
    frozenset(['t', 'c', 'p', 's', 'y', 'n']): 'TCP-SYN',  # Handles 'tcp-syn', 'TCP-SYN', etc.
    frozenset(['d', 'i', 'v', 'e', 'r', 's', 'i', 'o', 'n']): 'DIVERSION',
    frozenset(['p', 'o', 'r', 't', 's', 'c', 'a', 'n']): 'PORTSCAN',
    frozenset(['a', 't', 't', 'a', 'c', 'k']): 'ATTACK',
    frozenset(['b', 'l', 'a', 'c', 'k', 'h', 'o', 'l', 'e']): 'BLACKHOLE',
    frozenset(['o', 'v', 'e', 'r', 'f', 'l', 'o', 'w']): 'OVERFLOW',
    frozenset(['n', 'o', 'r', 'm', 'a', 'l']): 'NORMAL'
}

# Function to standardize based on letter sets
def standardize_text(text):
    if pd.isna(text) or not isinstance(text, str):
        return text
    text = text.lower().strip()
    # Split by hyphen and get unique letters, keeping hyphens as separators for initial check
    parts = text.split('-')
    all_letters = frozenset(c for part in parts for c in part if c.isalpha())  # Unique alphabetic chars
    
    for required_letters, standard_value in letter_mappings.items():
        if all_letters.issubset(required_letters):
            # Additional check for hyphenated forms if applicable
            if standard_value == 'TCP-SYN' and any('tcp' in part.lower() or 'syn' in part.lower() for part in parts):
                return standard_value
            return standard_value
    return text  # Return original if no match

# Apply standardization to 'Label' and 'Binary Label' columns
for column in ['Label', 'Binary Label']:
    if column in df.columns:
        df[column] = df[column].apply(standardize_text)

print("\nUpdated sample of categorical columns:")
print(df[['Label', 'Binary Label']].head())

# 1f. Universal inconsistency fix (YOUR METHOD)
# --------------------------------------------------------------
print("\n" + "="*50)
print("1f. UNIVERSAL NEGATIVE VALUE CORRECTION")
print("="*50)

# ---- Duplicates -------------------------------------------------
dup = df.duplicated().sum()
print(f"Duplicate rows: {dup}")
if dup:
    print(f"Removing {dup} duplicates (keeping first)...")
    df = df.drop_duplicates().reset_index(drop=True)
    print(f"Removed -> new shape: {df.shape}")
else:
    print("No duplicates found.")

# ---- Value-level correction ------------------------------------
print("\nApplying value-level correction to all numeric columns...")
numeric_cols = df.select_dtypes(include=[np.number]).columns

true_neg_total = 0
sentinel_total = 0

for col in numeric_cols:
    true_neg = ((df[col] < 0) & (df[col] != -1)).sum()
    sentinel = (df[col] == -1).sum()
    
    if true_neg or sentinel:
        print(f"  {col}:")
        if true_neg:
            print(f"    {true_neg} true negatives (<0, !=-1) -> 0")
            true_neg_total += true_neg
        if sentinel:
            print(f"    {sentinel} sentinel values (-1) -> NaN")
            sentinel_total += sentinel
    
    # Apply the rule
    df[col] = df[col].apply(
        lambda x: 0 if (x < 0 and x != -1) else (np.nan if x == -1 else x)
    )

print(f"\nSummary:")
print(f"  Total true negatives fixed : {true_neg_total}")
print(f"  Total -1 sentinels -> NaN : {sentinel_total}")
print("="*50 + "\n")

# --------------------------------------------------------------

# 1g. Print the number of unique categories in each categorical field
print("\n=== Task 1g: Unique Category Counts for Categorical Fields ===")
print("This section displays the number of unique categories in each categorical column.")
print("Categorical fields include text-based (object) data types and binary (bool) fields, such as labels, identifiers, or true/false indicators.\n")

# Identify categorical columns (object type and bool type)
categorical_cols = df.select_dtypes(include=['object', 'bool']).columns

# Print unique categories for each categorical field
for col in categorical_cols:
    unique_count = df[col].nunique()  # Corrected to use col
    print(f"- {col}:")
    print(f"  Number of unique categories: {unique_count}")
    print()

print("=== End of Task 1g ===")


# Requirement 1h: Check and print the maximum, minimum, average, and variance for each field (column)
print("\n1g. Statistics per field:")
for column in df.columns:
    if df[column].dtype in ['int64', 'float64']:  # Only numeric fields
        print(f"{column}:")
        print(f"  Max: {df[column].max()}")
        print(f"  Min: {df[column].min()}")
        print(f"  Average: {df[column].mean()}")
        print(f"  Variance: {df[column].var()}")

# Requirement 1i: Divide each data field into 4 quarters and calculate statistics
print("\n1i. Quartile Statistics:")
print("-"*80)

for column in df.columns:
    if df[column].dtype in ['int64', 'float64']:  # Only numeric fields
        print(f"\n{column}:")
        
        try:
            # Divide data into 4 quarters based on value
            quartiles = pd.qcut(df[column], q=4, labels=['Q1', 'Q2', 'Q3', 'Q4'], duplicates='drop')
            
            # Calculate statistics for each quarter
            for quarter_label in ['Q1', 'Q2', 'Q3', 'Q4']:
                if quarter_label in quartiles.values:
                    quarter_data = df[column][quartiles == quarter_label]
                    
                    print(f"  {quarter_label} (n={len(quarter_data)}):")
                    print(f"    Maximum:  {quarter_data.max():.6f}")
                    print(f"    Minimum:  {quarter_data.min():.6f}")
                    print(f"    Average:  {quarter_data.mean():.6f}")
                    print(f"    Variance: {quarter_data.var():.6f}")
        
        except Exception as e:
            print(f"  Unable to create quarters (likely constant values)")
            print(f"  Unique values: {df[column].nunique()}")



 # ========================================
# 2. Expand attack type into one-hot fields
# ========================================
print("\n" + "="*60)
print("2. ONE-HOT ENCODING ATTACK TYPES")
print("="*60)

# Get unique attack types from 'Label' column
attack_types = df['Label'].unique()
print(f"Unique attack types: {list(attack_types)}")

# Create one binary column per attack type
for attack in attack_types:
    # Replace spaces with underscores for valid column names
    col_name = f'Attack_{attack.replace(" ", "_")}'
    df[col_name] = (df['Label'] == attack).astype(int)

# List of one-hot columns
one_hot_cols = [c for c in df.columns if c.startswith('Attack_')]

# Verify: each row must have exactly one '1'
row_sums = df[one_hot_cols].sum(axis=1)
assert (row_sums == 1).all(), "ERROR: Some rows have multiple or zero attack flags!"

print(f"One-hot columns created: {one_hot_cols}")
print("Sample:")
print(df[one_hot_cols].head())
print("="*60 + "\n")




# =======================================================================
def safe_name(name):
    return str(name).replace('/', '_').replace('\\', '_').replace(' ', '_')


# =======================================================================
# REQUIREMENT 3 - Calculate and Plot PMF / PDF for All Fields
# =======================================================================

def plot_pmf_pdf(df):
    print("\n==================== Requirement 3 ====================")

    for col in df.columns:
        data = df[col].dropna()
        if data.empty:
            print(f"[Skipped] {col} — all values are NaN or invalid.")
            continue

        plt.figure(figsize=(10, 6))
        plt.grid(True, alpha=0.3)

        is_discrete = data.nunique() <= 20

        if is_discrete:
            pmf = data.value_counts(normalize=True).sort_index()
            plt.bar(range(len(pmf)), pmf.values, edgecolor='black', color='steelblue')
            plt.xticks(range(len(pmf)), pmf.index, rotation=45, ha='right', fontsize=8)
            plt.title(f'PMF of {col}')
            plt.ylabel('Probability')
        else:
            plt.hist(data, bins=30, density=True, color='steelblue', alpha=0.7, edgecolor='black')
            plt.title(f'PDF of {col}')
            plt.ylabel('Density')

        plt.xlabel(col)
        plt.tight_layout()
        safe_col = safe_name(col)
        plt.savefig(f'pmf_pdf_{safe_col}.png', dpi=300)
        plt.close()


# =======================================================================
# REQUIREMENT 4 - Calculate and Plot CDF for Numeric Fields
# =======================================================================

def plot_cdf(df):
    print("\n==================== Requirement 4 ====================")

    numeric_cols = df.select_dtypes(include=[np.number]).columns

    for col in numeric_cols:
        clean_data = df[col].dropna()
        if clean_data.empty:
            print(f"[Skipped] {col} — all values are NaN or invalid.")
            continue

        plt.figure(figsize=(10, 6))
        sorted_data = np.sort(clean_data)
        cdf = np.arange(1, len(sorted_data) + 1) / len(sorted_data)

        plt.plot(sorted_data, cdf, linewidth=2, color='steelblue')
        plt.xlabel(col)
        plt.ylabel('Cumulative Probability')
        plt.title(f'CDF of {col}')
        plt.grid(True, alpha=0.3)
        plt.tight_layout()
        safe_col = safe_name(col)
        plt.savefig(f'cdf_{safe_col}.png', dpi=300)
        plt.close()


# =======================================================================
def plot_conditional_pmf_pdf(df, label_col='Label'):
    print("\n==================== Requirement 5 ====================")
    print("Generating conditional PMF/PDF plots for all fields...\n")

    attack_types = df[label_col].dropna().unique()
    plot_count = 0

    for col in df.columns:
        if col == label_col or df[col].dropna().empty:
            continue

        data_all = df[col].dropna()
        is_discrete = data_all.nunique() <= 20

        for attack in attack_types:
            data_cond = df[df[label_col] == attack][col].dropna()
            if data_cond.empty:
                continue

            plt.figure(figsize=(12, 6))
            # refined dashed grid, like previous improved style
            plt.grid(color='gray', linestyle='--', linewidth=0.6, alpha=0.6)

            if is_discrete:
                pmf_all = data_all.value_counts(normalize=True).sort_index()
                pmf_cond = data_cond.value_counts(normalize=True).sort_index()

                # overlapping bars: overall (wider) behind, conditional (narrower) in front
                indices = np.arange(len(pmf_all.index))
                # Use pmf_all.index if categories align; ensure mapping if indexes differ
                # Build a unified index order:
                all_indices = sorted(set(pmf_all.index) | set(pmf_cond.index))
                x_pos = np.arange(len(all_indices))
                heights_all = [pmf_all.get(x, 0) for x in all_indices]
                heights_cond = [pmf_cond.get(x, 0) for x in all_indices]

                plt.bar(x_pos, heights_all, width=0.6,
                        alpha=0.7, color='blue', edgecolor='black', label='Overall PMF')
                plt.bar(x_pos, heights_cond, width=0.4,
                        alpha=0.7, color='red', edgecolor='black',
                        label=f'Conditional PMF (Attack={attack})')

                plt.xticks(x_pos, all_indices, rotation=45 if len(all_indices) > 10 else 0)
                plt.ylabel('Probability P(X=x)', fontsize=11, fontweight='bold')
                plt.title(f'PMF of {col} (Overall in blue, Given Attack in red)', fontsize=13, fontweight='bold')
                plt.grid(True, alpha=0.3, axis='y')

            else:
                # continuous: overlapping histograms with same bins
                bins = np.linspace(data_all.min(), data_all.max(), 50)
                plt.hist(data_all, bins=bins, density=True, alpha=0.7,
                         color='blue', edgecolor='black', label='Overall PDF')
                plt.hist(data_cond, bins=bins, density=True, alpha=0.7,
                         color='red', edgecolor='black', label=f'Conditional PDF (Attack={attack})')

                plt.ylabel('Density f(x)', fontsize=11, fontweight='bold')
                plt.title(f'PDF of {col} (Overall in blue, Given Attack in red)', fontsize=13, fontweight='bold')
                plt.grid(True, alpha=0.3, axis='y')

            # common layout and save
            plt.xlabel(col, fontsize=11, fontweight='bold')
            plt.legend(frameon=True, facecolor='white', edgecolor='black', fontsize=10)
            plt.tight_layout()

            safe_col = safe_name(col)
            safe_attack = safe_name(attack)
            filename = f'conditional_{safe_col}_{safe_attack}.png'
            plt.savefig(filename, dpi=400, bbox_inches='tight')
            plt.close()

            plot_count += 1
            print(f"[{plot_count}] Generated conditional PMF/PDF for: {col:35s} -> {filename}")

    print(f"\n{'-'*80}")
    print(f"Total conditional plots generated: {plot_count}")
    print("All conditional PMF/PDF plots saved successfully!")
    print("="*80)


# =======================================================================
# REQUIREMENT 6 - Scatter Plots to Show Relation Between Data Fields
# =======================================================================

def plot_scatter_relations(df):
    print("\n==================== Requirement 6 ====================")
    print("Generating scatter plots to show relationships between key data fields...\n")

    # --- define your chosen field pairs here ---
    scatter_pairs = [
        ('Sent Packets', 'Received Bytes'),
        ('Delta Received Packets', 'Delta Sent Packets'),
        ('Port Alive Duration', 'Delta Received Bytes'),
        ('Sent Bytes', 'Received Bytes'),                # NEW
        ('Port Alive Duration', 'Received Bytes')        # NEW
    ]

    plot_count = 0

    for x_field, y_field in scatter_pairs:
        # Skip if either column is missing
        if x_field not in df.columns or y_field not in df.columns:
            print(f"[Skipped] One of the fields not found: {x_field}, {y_field}")
            continue

        x_data = df[x_field].dropna()
        y_data = df[y_field].dropna()

        temp_df = df[[x_field, y_field]].dropna()
        if temp_df.empty:
            print(f"[Skipped] {x_field} vs {y_field} — no valid data after cleaning.")
            continue

        plt.figure(figsize=(8, 6))
        plt.scatter(temp_df[x_field], temp_df[y_field],
                    s=25, alpha=0.6, color='blue', edgecolor='black')

        plt.xlabel(x_field, fontsize=11, fontweight='bold')
        plt.ylabel(y_field, fontsize=11, fontweight='bold')
        plt.title(f"Scatter Plot: {x_field} vs {y_field}",
                  fontsize=13, fontweight='bold')
        plt.grid(True, linestyle='--', linewidth=0.6, alpha=0.6)
        plt.tight_layout()

        safe_x = safe_name(x_field)
        safe_y = safe_name(y_field)
        filename = f"scatter_{safe_x}_vs_{safe_y}.png"
        plt.savefig(filename, dpi=400, bbox_inches='tight')
        plt.close()

        plot_count += 1
        print(f"[{plot_count}] Generated scatter plot for: {x_field:25s} vs {y_field:25s} -> {filename}")

    print(f"\n{'-'*80}")
    print(f"Total scatter plots generated: {plot_count}")
    print("All scatter relation plots saved successfully!")
    print("="*80)






# =======================================================================
# REQUIREMENT 7 - Joint PMF/PDF of Two Different Fields
# =======================================================================

def plot_joint_pmf_pdf(df):
    print("\n==================== Requirement 7 ====================")
    print("Generating joint PMF/PDF plots for selected field pairs...\n")

    # choose pairs that make sense (you can edit freely)
    field_pairs = [
        ('Sent Packets', 'Received Bytes'),
        ('Delta Received Packets', 'Delta Sent Packets'),
        ('Port Alive Duration', 'Delta Received Bytes'),
        ('Sent Bytes', 'Received Bytes'),                # NEW
        ('Port Alive Duration', 'Received Bytes')        # NEW
    ]

    plot_count = 0

    for x_field, y_field in field_pairs:
        if x_field not in df.columns or y_field not in df.columns:
            print(f"[Skipped] One of the fields not found: {x_field}, {y_field}")
            continue

        temp_df = df[[x_field, y_field]].dropna()
        if temp_df.empty:
            print(f"[Skipped] {x_field} vs {y_field} — no valid data after cleaning.")
            continue

        is_discrete_x = temp_df[x_field].nunique() <= 20
        is_discrete_y = temp_df[y_field].nunique() <= 20
        is_discrete = is_discrete_x and is_discrete_y

        plt.figure(figsize=(8, 6))

        if is_discrete:
            joint_counts = temp_df.groupby([x_field, y_field]).size()
            joint_pmf = joint_counts / len(temp_df)
            joint_pmf = joint_pmf.unstack(fill_value=0)

            plt.imshow(joint_pmf.values, cmap='Blues', origin='lower', aspect='auto')
            plt.xticks(range(len(joint_pmf.columns)), joint_pmf.columns, rotation=45, ha='right')
            plt.yticks(range(len(joint_pmf.index)), joint_pmf.index)
            plt.colorbar(label='Joint Probability P(X,Y)')
            plt.title(f"Joint PMF of {x_field} and {y_field}", fontsize=13, fontweight='bold')

        else:
            plt.hist2d(temp_df[x_field], temp_df[y_field],
                       bins=40, density=True, cmap='Blues')
            plt.colorbar(label='Density f(x, y)')
            plt.title(f"Joint PDF of {x_field} and {y_field}", fontsize=13, fontweight='bold')

        plt.xlabel(x_field, fontsize=11, fontweight='bold')
        plt.ylabel(y_field, fontsize=11, fontweight='bold')
        plt.grid(True, linestyle='--', linewidth=0.6, alpha=0.6)
        plt.tight_layout()

        safe_x = safe_name(x_field)
        safe_y = safe_name(y_field)
        filename = f"joint_{safe_x}_vs_{safe_y}.png"
        plt.savefig(filename, dpi=400, bbox_inches='tight')
        plt.close()

        plot_count += 1
        print(f"[{plot_count}] Generated joint PMF/PDF for: {x_field:30s} vs {y_field:30s} -> {filename}")

    print(f"\n{'-'*80}")
    print(f"Total joint PMF/PDF plots generated: {plot_count}")
    print("All joint PMF/PDF plots saved successfully!")
    print("="*80)





# =======================================================================
# REQUIREMENT 8 - Joint PMF/PDF Conditioned on Attack Type
# =======================================================================

def plot_conditional_joint_pmf_pdf(df, label_col='Label'):
    print("\n==================== Requirement 8 ====================")
    print("Generating conditional joint PMF/PDF plots for selected field pairs...\n")

    field_pairs = [
        ('Sent Packets', 'Received Bytes'),
        ('Delta Received Packets', 'Delta Sent Packets'),
        ('Port Alive Duration', 'Delta Received Bytes'),
        ('Sent Bytes', 'Received Bytes'),                # NEW
        ('Port Alive Duration', 'Received Bytes')        # NEW
    ]

    attack_types = df[label_col].dropna().unique()
    plot_count = 0

    for x_field, y_field in field_pairs:
        if x_field not in df.columns or y_field not in df.columns:
            print(f"[Skipped] One of the fields not found: {x_field}, {y_field}")
            continue

        base_df = df[[x_field, y_field, label_col]].dropna()
        if base_df.empty:
            print(f"[Skipped] {x_field} vs {y_field} — no valid data after cleaning.")
            continue

        is_discrete_x = base_df[x_field].nunique() <= 20
        is_discrete_y = base_df[y_field].nunique() <= 20
        is_discrete = is_discrete_x and is_discrete_y

        for attack in attack_types:
            cond_df = base_df[base_df[label_col] == attack]
            if cond_df.empty:
                continue

            plt.figure(figsize=(10, 6))

            if is_discrete:
                joint_all = base_df.groupby([x_field, y_field]).size()
                joint_all = joint_all / len(base_df)
                joint_cond = cond_df.groupby([x_field, y_field]).size()
                joint_cond = joint_cond / len(cond_df)

                joint_all = joint_all.unstack(fill_value=0)
                joint_cond = joint_cond.unstack(fill_value=0)

                plt.subplot(1, 2, 1)
                plt.imshow(joint_all.values, cmap='Blues', origin='lower', aspect='auto')
                plt.xticks(range(len(joint_all.columns)), joint_all.columns, rotation=45, ha='right')
                plt.yticks(range(len(joint_all.index)), joint_all.index)
                plt.colorbar(label='P(X,Y)')
                plt.title('Overall Joint PMF', fontsize=12, fontweight='bold')

                plt.subplot(1, 2, 2)
                plt.imshow(joint_cond.values, cmap='Reds', origin='lower', aspect='auto')
                plt.xticks(range(len(joint_cond.columns)), joint_cond.columns, rotation=45, ha='right')
                plt.yticks(range(len(joint_cond.index)), joint_cond.index)
                plt.colorbar(label=f'P(X,Y | Attack={attack})')
                plt.title(f'Conditional Joint PMF ({attack})', fontsize=12, fontweight='bold')

                plt.suptitle(f"Joint PMF of {x_field} and {y_field} (Conditional on {attack})",
                             fontsize=13, fontweight='bold')

            else:
                bins = 40
                plt.subplot(1, 2, 1)
                plt.hist2d(base_df[x_field], base_df[y_field],
                           bins=bins, density=True, cmap='Blues')
                plt.colorbar(label='Density f(x, y)')
                plt.title('Overall Joint PDF', fontsize=12, fontweight='bold')
                plt.xlabel(x_field, fontsize=11, fontweight='bold')
                plt.ylabel(y_field, fontsize=11, fontweight='bold')
                plt.grid(True, linestyle='--', linewidth=0.6, alpha=0.6)

                plt.subplot(1, 2, 2)
                plt.hist2d(cond_df[x_field], cond_df[y_field],
                           bins=bins, density=True, cmap='Reds')
                plt.colorbar(label=f'Density f(x, y | Attack={attack})')
                plt.title(f'Conditional Joint PDF ({attack})', fontsize=12, fontweight='bold')
                plt.xlabel(x_field, fontsize=11, fontweight='bold')
                plt.ylabel(y_field, fontsize=11, fontweight='bold')
                plt.grid(True, linestyle='--', linewidth=0.6, alpha=0.6)

                plt.suptitle(f"Joint PDF of {x_field} and {y_field} (Conditional on {attack})",
                             fontsize=13, fontweight='bold')

            plt.tight_layout(rect=[0, 0, 1, 0.96])

            safe_x = safe_name(x_field)
            safe_y = safe_name(y_field)
            safe_attack = safe_name(attack)
            filename = f"joint_conditional_{safe_x}_vs_{safe_y}_{safe_attack}.png"
            plt.savefig(filename, dpi=400, bbox_inches='tight')
            plt.close()

            plot_count += 1
            print(f"[{plot_count}] Generated conditional joint PMF/PDF for: {x_field:30s} vs {y_field:30s} ({attack}) -> {filename}")

    print(f"\n{'-'*80}")
    print(f"Total conditional joint PMF/PDF plots generated: {plot_count}")
    print("All conditional joint PMF/PDF plots saved successfully!")
    print("="*80)




# =======================================================================
# REQUIREMENT 9 - Calculate the Correlation Between Different Data Fields
# =======================================================================

def calculate_correlations(df):
    print("\n==================== Requirement 9 ====================")
    print("Calculating correlation between numeric data fields...\n")

    # Select numeric columns only
    numeric_df = df.select_dtypes(include=[np.number])

    if numeric_df.empty:
        print("[Skipped] No numeric columns found for correlation analysis.")
        return

    # Compute correlation matrix
    corr_matrix = numeric_df.corr(method='pearson')

    # Flatten and clean correlation pairs
    corr_pairs = corr_matrix.unstack().dropna().reset_index()
    corr_pairs.columns = ['Feature1', 'Feature2', 'Correlation']

    # Remove self-correlations and duplicate mirror pairs (A,B) and (B,A)
    corr_pairs = corr_pairs[corr_pairs['Feature1'] < corr_pairs['Feature2']]

    # Sort correlations
    corr_pairs_sorted = corr_pairs.sort_values(by='Correlation', ascending=False)

    # Get top unique correlations
    top_positive = corr_pairs_sorted.head(10)
    top_negative = corr_pairs_sorted.tail(10)

    # Print results
    print("Top 10 Strongest Positive Correlations (unique pairs):")
    print(top_positive.to_string(index=False))
    print("\nTop 10 Strongest Negative Correlations (unique pairs):")
    print(top_negative.to_string(index=False))

    # Display a small sample of the correlation matrix
    print("\nSample of correlation matrix (top-left corner):\n")
    print(corr_matrix.iloc[:5, :5].round(3))

    print("\n[Done] Correlation matrix calculated and sample displayed.")
    print("="*80)



# =======================================================================
# REQUIREMENT 10 - Find Which Fields Are Dependent on the Type of Attack
# =======================================================================

def find_attack_dependent_fields(df, label_col='Label'):
    print("\n==================== Requirement 10 ====================")
    print("Finding which fields are dependent on the attack type...\n")

    if label_col not in df.columns:
        print(f"[Error] '{label_col}' column not found in dataset.")
        return

    # Select numeric columns only (categorical are not useful for this calculation)
    numeric_cols = df.select_dtypes(include=[np.number]).columns

    if numeric_cols.empty:
        print("[Skipped] No numeric fields available for dependency analysis.")
        return

    # Convert label column to string for grouping consistency
    df[label_col] = df[label_col].astype(str)
    attack_types = df[label_col].unique()

    print(f"Detected {len(attack_types)} attack types: {attack_types}\n")

    # Compute mean of each numeric column per attack type
    group_means = df.groupby(label_col)[numeric_cols].mean()

    # Compute the absolute difference between max and min mean across attack types
    mean_differences = group_means.max() - group_means.min()

    # Determine a dynamic threshold for dependency
    threshold = mean_differences.mean() + (0.5 * mean_differences.std())

    print(f"Dependency threshold (mean + 0.5·std): {threshold:.4f}\n")

    # Identify fields exceeding the threshold
    dependent_fields = mean_differences[mean_differences >= threshold].index.tolist()

    if dependent_fields:
        print("Fields showing significant variation across attack types:")
        for i, field in enumerate(dependent_fields, 1):
            print(f"  {i}. {field}")
    else:
        print("No strong dependencies detected based on mean variation across attacks.")

    # Display a sample of variation values
    print("\nSample of mean differences between attack types (first 10 fields):\n")
    print(mean_differences.head(10).round(3))

    print("\n[Done] Attack dependency analysis completed.")
    print("="*80)



# =======================================================================
# To Run Each Requirement:
# =======================================================================
# Example usage after loading and cleaning df in your main code:

plot_pmf_pdf(df)
plot_cdf(df)
plot_conditional_pmf_pdf(df)
plot_scatter_relations(df)
plot_joint_pmf_pdf(df)
plot_conditional_joint_pmf_pdf(df)
calculate_correlations(df)
find_attack_dependent_fields(df)



